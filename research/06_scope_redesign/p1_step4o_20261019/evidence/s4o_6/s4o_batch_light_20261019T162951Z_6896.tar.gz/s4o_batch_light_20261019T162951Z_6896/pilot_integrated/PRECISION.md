# PRECISION（第 119 项 C1，第 120 项运行验收；只读，未启动 Gurobi）

- 运行：`/root/autodl-tmp/s4m_cloud/runs/20261019T072454Z_5125/integrated`（None，None，档案 None）；终止 `optimal`；目标 516252148340.3703；基于**最终返回解**（solution/X、Pi、RC）。
- **验收（第 120 项 = optimal + (a)(b)(c)）：True**（optimal True，(a) True，(b) True，(c) True）
- 分级：**layer1_plus_nodal_price_settlement**（按电价结算：usable）
- 分国容差参照：this batch: disconnected - integrated ledger difference (/root/autodl-tmp/s4o_cloud/runs/20261019T162951Z_6896/disconnected minus /root/autodl-tmp/s4n_pilot/integrated, COUNTRY_COST_LEDGER.csv total)
- 重评记录：the pilot has only the integrated run: per-country threshold… → layer1_plus_nodal_price_settlement（验收 None）
- 项目门槛（数值信息，不作判据）：`all_passed_solver_tolerances` None；不通过 无

## (a) 总成本精度

- 第一轮停滞前最好迭代（原始残差最小）：第 153 次，原始 5.133657260e+11，对偶 5.133652580e+11，差 -4.68e+05 EUR（相对 9.12e-07），原始残差 3.08，对偶残差 0.000399，互补 0.206，4092 s
- 最终返回解（日志中与回执 objective_lp 相同的迭代）：第 398 次，原始 5.133654210e+11，对偶 5.133654400e+11，差 1.9e+04 EUR（相对 3.70e-08），原始残差 1.05，对偶残差 0.000231，互补 0.0299，11153 s
- 最后一次迭代：第 408 次，原始 5.133654130e+11，对偶 5.133654260e+11，差 1.3e+04 EUR（相对 2.53e-08），原始残差 0.887，对偶残差 0.000766，互补 0.0273，11470 s
- 重启后原始残差最小的迭代：第 393 次，原始 5.133654310e+11，对偶 5.133654550e+11，差 2.4e+04 EUR（相对 4.68e-08），原始残差 0.886，对偶残差 0.000518，互补 0.0331，10994 s
- 重启：第 156 次（4194 s）
- 返回数组的 KKT 摘要：原始 516252148340.3428，对偶 516252084170.29266，差 -0.000064 bn，相对 1.24e-07 → 标准（≤ 0.01 bn 且 ≤ 1e-5）：**True**

## (b) 原始违反（L23 §6 方法）

- 有正违反的行 1,311,383，超预算 2,371（与 `l23_violation_analysis.py` 一致：True），最大违反 4.217，最大为预算 279 倍；一阶影响合计 37,844 EUR

| 国 | 一阶影响 bn | 阈值 bn | 通过 |
|---|---|---|---|
| BN | 1.92e-07 | 0.0100 | True |
| ID | 3.88e-06 | 0.0100 | True |
| KH | 1.69e-06 | 0.0243 | True |
| LA | 1.10e-05 | 0.0274 | True |
| MM | 6.29e-06 | 0.0113 | True |
| MY | 8.23e-07 | 0.0321 | True |
| PH | 1.07e-06 | 0.0100 | True |
| SG | 6.00e-08 | 0.0100 | True |
| TH | 2.27e-06 | 0.0751 | True |
| TL | 1.37e-07 | 0.0100 | True |
| VN | 3.09e-06 | 0.5159 | True |
| ASEAN | 7.38e-06 | 0.0122 | True |

- BN / SG / VN 生物质池行：超预算行中 1 / 2371；最大倍数的行不是此类行；仍占主导：**False**

## (c) 价格质量

- B16 账本恒等式：相对误差 7.2038610202070544e-09（≤ 1e-6）→ **True**
- KKT 残差对分国结算的影响（INFERENCE；rows / columns by the component's bus country; cross-border components counted fully for both countries）：

| 国 | 驻点 S bn | 行互补 R bn | S+R bn | 列互补 K bn | 自由列符号 bn | 阈值 bn | S+R 通过 | 全部项通过 |
|---|---|---|---|---|---|---|---|---|
| BN | 1.86e-07 | 2.31e-06 | 2.50e-06 | 1.14e-08 | 1.04e-09 | 0.0100 | True | True |
| ID | 1.45e-05 | 5.22e-05 | 6.68e-05 | 8.82e-07 | 3.24e-07 | 0.0100 | True | True |
| KH | 1.52e-06 | 9.23e-06 | 1.07e-05 | 3.37e-07 | 1.07e-07 | 0.0243 | True | True |
| LA | 1.05e-06 | 1.18e-05 | 1.28e-05 | 6.30e-07 | 1.95e-07 | 0.0274 | True | True |
| MM | 2.29e-06 | 2.37e-05 | 2.60e-05 | 7.05e-07 | 2.07e-07 | 0.0113 | True | True |
| MY | 4.30e-06 | 1.22e-05 | 1.65e-05 | 3.08e-07 | 8.14e-08 | 0.0321 | True | True |
| PH | 2.04e-06 | 9.82e-06 | 1.19e-05 | 1.72e-07 | 7.21e-08 | 0.0100 | True | True |
| SG | 5.30e-07 | 1.36e-06 | 1.89e-06 | 8.94e-09 | 1.85e-08 | 0.0100 | True | True |
| TH | 7.13e-06 | 1.24e-05 | 1.96e-05 | 5.03e-07 | 2.02e-07 | 0.0751 | True | True |
| TL | 2.72e-08 | 2.36e-06 | 2.39e-06 | 1.19e-08 | 6.55e-09 | 0.0100 | True | True |
| VN | 5.88e-06 | 1.43e-05 | 2.01e-05 | 4.68e-07 | 3.46e-07 | 0.5159 | True | True |
| ASEAN | 2.12e-06 | 6.99e-06 | 9.11e-06 | 0.00e+00 | 6.77e-07 | 0.0122 | True | True |

- (c) 判定（B16 且每国 S+R ≤ 阈值）：**True**（全部项：True）

用时 71 s。
